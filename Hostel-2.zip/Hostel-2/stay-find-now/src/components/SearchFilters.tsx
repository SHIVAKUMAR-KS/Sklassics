import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Search } from "lucide-react";
import { format } from "date-fns";

interface SearchFiltersProps {
  onSearch: (filters: SearchFilters) => void;
}

export interface SearchFilters {
  location: string;
  priceRange: string;
  roomType: string;
  amenities: string;
  gender: string;
  checkIn?: Date;
}

const SearchFilters = ({ onSearch }: SearchFiltersProps) => {
  const [location, setLocation] = useState("");
  const [priceRange, setPriceRange] = useState("");
  const [roomType, setRoomType] = useState("");
  const [amenities, setAmenities] = useState("");
  const [gender, setGender] = useState("");
  const [checkIn, setCheckIn] = useState<Date>();

  const handleSearch = () => {
    onSearch({
      location,
      priceRange,
      roomType,
      amenities,
      gender,
      checkIn
    });
  };

  return (
    <div className="bg-card p-6 rounded-lg border">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 mb-4">
        {/* Location Input */}
        <div className="lg:col-span-2">
          <Input
            placeholder="Enter location or hostel name"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full"
          />
        </div>

        {/* Check-in Date */}
        <div>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {checkIn ? format(checkIn, "MMM dd, yyyy") : "Check-in date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={checkIn}
                onSelect={setCheckIn}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Price Range */}
        <div>
          <Select value={priceRange} onValueChange={setPriceRange}>
            <SelectTrigger>
              <SelectValue placeholder="Price Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">Any Price</SelectItem>
              <SelectItem value="0-5000">₹0 - ₹5,000</SelectItem>
              <SelectItem value="5000-10000">₹5,000 - ₹10,000</SelectItem>
              <SelectItem value="10000-15000">₹10,000 - ₹15,000</SelectItem>
              <SelectItem value="15000+">₹15,000+</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Room Type */}
        <div>
          <Select value={roomType} onValueChange={setRoomType}>
            <SelectTrigger>
              <SelectValue placeholder="Room Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="shared">Shared Room</SelectItem>
              <SelectItem value="private">Private Room</SelectItem>
              <SelectItem value="dormitory">Dormitory</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Search Button */}
        <div>
          <Button onClick={handleSearch} className="w-full">
            <Search className="mr-2 h-4 w-4" />
            Search Hostels
          </Button>
        </div>
      </div>

      {/* Additional Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Amenities */}
        <div>
          <Select value={amenities} onValueChange={setAmenities}>
            <SelectTrigger>
              <SelectValue placeholder="All Amenities" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Amenities</SelectItem>
              <SelectItem value="wifi">WiFi</SelectItem>
              <SelectItem value="ac">AC</SelectItem>
              <SelectItem value="gym">Gym</SelectItem>
              <SelectItem value="meals">Meals</SelectItem>
              <SelectItem value="laundry">Laundry</SelectItem>
              <SelectItem value="pool">Pool</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Gender */}
        <div>
          <Select value={gender} onValueChange={setGender}>
            <SelectTrigger>
              <SelectValue placeholder="Gender" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="male">Male</SelectItem>
              <SelectItem value="female">Female</SelectItem>
              <SelectItem value="co-ed">Co-ed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};

export default SearchFilters;